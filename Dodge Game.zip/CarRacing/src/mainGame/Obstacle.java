package mainGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Obstacle {
    private int x, y;
    private int dy;

    public Obstacle(int x, int y) {
        this.x = x;
        this.y = y;
        this.dy = 5;
    }

    public void move() {
        y += dy;
    }

    public int getY() {
        return y;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 50, 50);
    }

    public void draw(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(x, y, 50, 50);
    }
}
