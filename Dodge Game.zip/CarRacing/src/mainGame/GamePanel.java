package mainGame;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    private Car car;
    private List<Obstacle> obstacles;
    private Timer timer;
    private Random random;

    public GamePanel() {
        this.car = new Car(350, 500);
        this.obstacles = new ArrayList<>();
        this.timer = new Timer(20, this);
        this.random = new Random();

        setFocusable(true);
        addKeyListener(this);
    }

    public void startGame() {
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the car
        car.draw(g);

        // Draw obstacles
        for (Obstacle obstacle : obstacles) {
            obstacle.draw(g);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        car.move();
        spawnObstacles();
        moveObstacles();
        checkCollisions();
        repaint();
    }

    private void spawnObstacles() {
        if (random.nextInt(100) < 5) {
            int x = random.nextInt(getWidth() - 50);
            obstacles.add(new Obstacle(x, 0));
        }
    }

    private void moveObstacles() {
        List<Obstacle> obstaclesToRemove = new ArrayList<>();
        for (Obstacle obstacle : obstacles) {
            obstacle.move();
            if (obstacle.getY() > getHeight()) {
                obstaclesToRemove.add(obstacle);
            }
        }
        obstacles.removeAll(obstaclesToRemove);
    }

    private void checkCollisions() {
        for (Obstacle obstacle : obstacles) {
            if (car.getBounds().intersects(obstacle.getBounds())) {
                timer.stop();
                System.out.println("Game Over!");
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            car.setDx(-5);
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            car.setDx(5);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT) {
            car.setDx(0);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}
