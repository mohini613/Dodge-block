package mainGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Car {
    private int x, y;
    private int dx;

    public Car(int x, int y) {
        this.x = x;
        this.y = y;
        this.dx = 0;
    }

    public void move() {
        x += dx;
        if (x < 0) x = 0;
        if (x > 750) x = 750;
    }

    public void setDx(int dx) {
        this.dx = dx;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 50, 100);
    }

    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, 50, 100);
    }
}
